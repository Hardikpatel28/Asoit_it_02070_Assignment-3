<?php
		$servername = "localhost";
        $username = "root";
        $password = "";
        $databasename = "student details";
        
        $conn = mysqli_connect($servername, $username, $password, $databasename);

		if ($conn->connect_error) {
            die($conn->connect_error);
        } else {
            echo "MySql Connection Successful!";
        }
        
		$name = $_REQUEST['name'];
		$email= $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$country = $_REQUEST['country'];
		$gender = $_REQUEST['gender'];
		$feedback =$_REQUEST["feedback"];


		$sql = "INSERT INTO student VALUES ('$name','$email','$mobile','$country','$gender','$feedback')";
		
		if(mysqli_query($conn, $sql)){
			echo "Successfully Saved";
		} else{
			echo "ERROR $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>